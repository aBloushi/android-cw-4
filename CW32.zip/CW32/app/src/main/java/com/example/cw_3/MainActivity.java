package com.example.cw_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import javax.xml.transform.Result;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button AddButton = (Button) findViewById(R.id.AddButton);
        Button ResetButton = (Button) findViewById(R.id.Resetbtn);
        final EditText num1 = (EditText) findViewById(R.id.num1);
        final EditText num2 = (EditText) findViewById(R.id.num2);
        Button MulBtn = (Button) findViewById(R.id.mulbtn);
        Button Divbtn = (Button) findViewById(R.id.divbtn);

        AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                int number1 = Integer.parseInt(num1.getText().toString());
                int number2 = Integer.parseInt(num2.getText().toString());
                int result = number1 + number2;
                Toast.makeText(MainActivity.this, result+"", Toast.LENGTH_SHORT).show();

            }
        });
        MulBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int number1 = Integer.parseInt(num1.getText().toString());
                int number2 = Integer.parseInt(num2.getText().toString());
                int result = number1 * number2;
                Toast.makeText(MainActivity.this, result+"", Toast.LENGTH_SHORT).show();
            }
        });
        Divbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int number1 = Integer.parseInt(num1.getText().toString());
                int number2 = Integer.parseInt(num2.getText().toString());
                int result = number1 / number2;
                Toast.makeText(MainActivity.this, result+"", Toast.LENGTH_SHORT).show();
            }
        });
        ResetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //can put null
                num1.setText("0");
                num2.setText("0");
            }
        });
    }
}